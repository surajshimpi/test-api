context.setVariable("response.header.X-Apigee-Demo-ProxyBasePath", context.getVariable("proxy.basepath"));
context.setVariable("response.header.X-Apigee-Demo-ProxyPathSuffix", context.getVariable("proxy.pathsuffix"));
context.setVariable("response.header.X-Apigee-Demo-ProxyUrl", context.getVariable("proxy.url"));